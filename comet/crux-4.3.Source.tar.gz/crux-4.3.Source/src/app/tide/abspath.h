#ifndef ABSPATH_H
#define ABSPATH_H

#include <string>

std::string AbsPath(const std::string& rel_path);

#endif
