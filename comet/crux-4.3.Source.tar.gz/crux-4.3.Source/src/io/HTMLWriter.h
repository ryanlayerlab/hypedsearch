#ifndef HTMLWRITER_H
#define HTMLWRITER_H

#include <vector>

#include "PMCDelimitedFileWriter.h"

class HTMLWriter : public PMCDelimitedFileWriter {

 public:

  HTMLWriter();

  ~HTMLWriter();

};

#endif
