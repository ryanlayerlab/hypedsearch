/*
Abstract class for a peptide-spectrum match writers
*/

#include "PSMWriter.h"

PSMWriter::PSMWriter() {
}

PSMWriter::~PSMWriter() {
}
